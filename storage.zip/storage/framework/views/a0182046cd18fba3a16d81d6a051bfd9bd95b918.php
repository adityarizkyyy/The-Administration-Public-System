

<?php $__env->startSection('container-rw'); ?>
    <div class="main-box-form">
        <center>
            <h1 class="judul"><?php echo e($title); ?></h1>
            <h4 class="notice"><?php echo e($notice); ?></h4>
        </center>
        <div>
            <div>
                <div class="sec-box-form">
                    <form action="<?php echo e(route('rw.sp', [$permohonan])); ?>" enctype="multipart/form-data" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3 mt-5">
                            <label for="exampleInputEmail1" class="form-label">Nomor SP</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                                name="nosp">
                        </div>
                        <div class="mb-5">
                            <label for="formFile" class="form-label">Surat Permohonan</label>
                            <input class="form-control" type="file" id="formFile" name="filesp">
                        </div>

                        <span>
                            <center>
                                <!-- ketika rw klik upload sp, status progres juga diupdate jadi : SP telah disetujui, dan kirim email ke email yg terdaftar : 'SP telah disetujui'-->
                                <button type="submit" class="sec-button mt-5 ">Upload</button>
                            </center>
                        </span>

                    </form>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-rw', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/rw-upload-sp.blade.php ENDPATH**/ ?>