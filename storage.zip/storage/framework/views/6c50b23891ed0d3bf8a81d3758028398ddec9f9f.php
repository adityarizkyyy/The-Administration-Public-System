<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- Link CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <!-- Bostrap Icon -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">

    <title>APEM15 | <?php echo e($title); ?></title>
</head>

<body>

    <?php echo $__env->make('partials.navbar-rt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($message = Session::get('success')): ?>
        

        

        <div class="modal fade" id="modalSuccess" tabindex="-1" aria-labelledby="modalSuccessLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">

                    <div class="modal-body text-center">
                        <h1 style="font-size: 6em"><i class="bi bi-check-circle-fill text-success text-bold"></i></h1>
                        <h3>Success</h3>
                        <p><?php echo e($message); ?></p>
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                    </div>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get('error')): ?>
        

        

        <div class="modal fade" id="modalError" tabindex="-1" aria-labelledby="modalErrorLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">

                    <div class="modal-body text-center">
                        <h1 style="font-size: 6em"><i class="bi bi-x-circle-fill text-danger text-bold"></i></h1>
                        <h3>Error</h3>
                        <p><?php echo e($message); ?></p>
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                    </div>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="container mt-4">
        <!-- mt : margin top -->
        <?php echo $__env->yieldContent('container-rt'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
    <?php if($message = Session::get('success')): ?>
        <script>
            var myModal = new bootstrap.Modal(document.getElementById('modalSuccess'))
            // var modalToggle = document.getElementById('modalSuccess') // relatedTarget
            myModal.show()
        </script>
    <?php endif; ?>
    <?php if($message = Session::get('error')): ?>
        <script>
            var myModal = new bootstrap.Modal(document.getElementById('modalError'))
            // var modalToggle = document.getElementById('modalError') // relatedTarget
            myModal.show()
        </script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/layouts/main-rt.blade.php ENDPATH**/ ?>