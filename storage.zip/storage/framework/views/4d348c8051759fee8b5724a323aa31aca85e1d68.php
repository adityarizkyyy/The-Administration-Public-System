<!DOCTYPE html>
<html lang="en-US">

<head>
    <meta charset="utf-8">
</head>

<body>
    <h2>Demo mail from JustLaravel</h2>

    <?php if(isset($bodyMessage)): ?>
        <div class="w3-container w3-orange">

            <p>
                <b>The data you have entered is :</b><span style="color: #e36c39; background: #EEE" ;>
                    <?php echo e($bodyMessage); ?></span>

            </p>

        </div>
    <?php endif; ?>
</body>

</html>
<?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/email.blade.php ENDPATH**/ ?>