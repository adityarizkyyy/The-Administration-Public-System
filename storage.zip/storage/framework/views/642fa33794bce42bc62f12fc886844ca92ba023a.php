

<?php $__env->startSection('container'); ?>
    <center>
        <h1 class="judul">Silahkan Pilih Permohonan</h1>
        <p class="judul"></p>
        <div class="judul">
            <a href="<?php echo e(route('persyaratan', ['need' => 'ktp'])); ?>">
                <button class="perm-button">Permohonan Penerbitan KTP</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'kk'])); ?>">
                <button class="perm-button">Permohonan Penerbitan KK</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'sktm'])); ?>">
                <button class="perm-button">Permohonan Pengajuan SKTM</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'kjp'])); ?>">
                <button class="perm-button">Permohonan Pengajuan KJP</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'pk'])); ?>">
                <button class="perm-button">Permohonan Pindah Keluar</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'pd'])); ?>">
                <button class="perm-button">Permohonan Pindah Datang</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'um'])); ?>">
                <button class="perm-button">Permohonan Pengajuan Usaha Mikro</button>
            </a>

        </div>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/permohonan.blade.php ENDPATH**/ ?>