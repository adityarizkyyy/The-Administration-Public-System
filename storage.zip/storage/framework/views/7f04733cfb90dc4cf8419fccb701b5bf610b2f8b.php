

<?php $__env->startSection('container-rw'); ?>
    <center>
        <h1 class="judul"><?php echo e($title); ?></h1>
    </center>

    <div>
        <div>
            <a href="<?php echo e(route('rw.laporan.download', ['filter' => $filter])); ?>" class="btn button-unduh mt-3">
            <i class="bi bi-download"></i><span>  Unduh</span>
            </a>
            <div class="input-group mt-3">
                <select class="form-select" aria-label="Default select example"
                    onchange="window.location = '<?php echo e(route('rw.laporan')); ?>?filter=' + this.options[this.selectedIndex].value;">
                    <option <?php echo e($filter === '' ? 'selected ' : ''); ?>hidden>Filter Sesuai Jenis Permohonan</option>
                    <option <?php echo e($filter === 'all' ? 'selected ' : ''); ?>value="all">Semua Jenis Permohonan</option>
                    <option <?php echo e($filter === 'ktp' ? 'selected ' : ''); ?>value="ktp">Penerbitan KTP</option>
                    <option <?php echo e($filter === 'kk' ? 'selected ' : ''); ?>value="kk">Penerbitan KK</option>
                    <option <?php echo e($filter === 'sktm' ? 'selected ' : ''); ?>value="sktm">Pengajuan SKTM</option>
                    <option <?php echo e($filter === 'kjp' ? 'selected ' : ''); ?>value="kjp">Pengajuan KJP</option>
                    <option <?php echo e($filter === 'pk' ? 'selected ' : ''); ?>value="pk">Pindah Keluar</option>
                    <option <?php echo e($filter === 'pd' ? 'selected ' : ''); ?>value="pd">Pindah Datang</option>
                    <option <?php echo e($filter === 'um' ? 'selected ' : ''); ?>value="um">Pengajuan Usaha Mikro</option>
                </select>
            </div>
        </div>

        <div class="container">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Tanggal Permohonan</th>
                            <th scope="col">No Surat Permohonan</th>
                            <th scope="col">Nama Lengkap</th>
                            <th scope="col">Tanggal Lahir</th>
                            <th scope="col">No KTP</th>
                            <th scope="col">Status</th>
                            <th scope="col">Pekerjaan</th>
                            <th scope="col">Wilayah RT</th>
                            
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                            <tr>
                                <th scope="row"><?php echo e($key + 1); ?></th>
                                <td><?php echo e($item->created_at->format('d-m-Y')); ?></td>
                                <td><?php echo e($item->suratPermohonan?->nosp); ?></td>
                                <td><?php echo e($item->user?->personal?->nama); ?></td>
                                <td><?php echo e($item->user?->personal?->tgllahir->format('d-m-Y')); ?></td>
                                <td><?php echo e($item->user?->personal?->noktp); ?></td>
                                <td><?php echo e($item->user?->personal?->status); ?></td>
                                <td><?php echo e($item->user?->personal?->pekerjaan); ?></td>
                                <td><?php echo e($item->user?->personal?->wilayahrt); ?></td>
                                
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8">
                                    <p align="center">Data Kosong</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-rw', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplikasi\APEM15\resources\views/rw-laporan.blade.php ENDPATH**/ ?>