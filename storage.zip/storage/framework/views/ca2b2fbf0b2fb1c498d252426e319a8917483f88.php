

<?php $__env->startSection('container-rw'); ?>
    <div>
        <div>
            <a href="<?php echo e(route('rw.permintaan')); ?>">
                <button class="main-button mt-3">Permintaan
                    <span class="jum-perm-button">
                        <?php echo e($count); ?>

                        <!-- 10 di kiri = total jumlah permintaan persetujuan yang masuk (hasil terusan dari sk RT yg udh di upload) -->
                    </span>
                </button>
            </a><br>
        </div>


        <div>
            <section class="layer-slide-rw mt-1">
                <div class="swiper mySwiper">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $done; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <div class="card-box">
                                    <div class="content-card-box">
                                        <h1><?php echo e($item->jenis_permohonan); ?></h1>
                                        <p class="total-sp">
                                            <!-- total sp = total dari Surat Permohonan yang udh di upload sama rw (disesuikan jenisnya) -->
                                            <?php echo e($item->permohonan_count); ?>

                                            <!-- 5 di kiri ini = contoh total SP yang udh di upload sama rw -->
                                        </p>
                                        <a href="<?php echo e(route('rw.laporan', ['filter' => $item->kode_permohonan])); ?>">
                                            <button class="detail-sp">
                                                detail>
                                            </button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </section>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-rw', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplikasi\APEM15\resources\views/rw-home.blade.php ENDPATH**/ ?>