

<?php $__env->startSection('container-rw'); ?>

<center>
    <h1 class="judul"><?php echo e($judul); ?></h1>
</center>

<div>
    <div>
        <button class="main-button mt-3">Unduh</button>
    </div>
    
    <div class="untuk-tabel">
        <p align="center">tabel SP KTP yang udh di setujui (dikatakan disetujui ketika rw sudah upload sp)</p>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main-rw', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/rw-detail-sp-ktp.blade.php ENDPATH**/ ?>