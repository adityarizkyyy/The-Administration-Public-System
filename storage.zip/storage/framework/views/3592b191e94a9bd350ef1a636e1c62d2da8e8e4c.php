

<?php $__env->startSection('container'); ?>
    <center>
        <h1 class="judul"><?php echo e($title); ?></h1>
    </center>

    <div class="container">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Tanggal Permohonan</th>
                        <th scope="col">Jenis Permohonan</th>
                        <th scope="col">Status</th>
                        <th scope="col">File SP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        <tr>
                            <th scope="row"><?php echo e($key + 1); ?></th>
                            <td><?php echo e($item->created_at->format('d-m-Y')); ?></td>
                            <td><?php echo e($item->jenisPermohonan->jenis_permohonan); ?></td>
                            <td><?php echo e($item->status_progres); ?></td>
                            <td>
                                <?php if(isset($item->suratPermohonan->filesp)): ?>
                                    <a href="<?php echo e(route('download', ['link' => $item->suratPermohonan?->filesp])); ?>"
                                        target="_blank" class="btn btn-secondary">Unduh SP</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p align="center">Data Kosong</p>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/riwayat.blade.php ENDPATH**/ ?>