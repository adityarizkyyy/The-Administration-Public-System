

<?php $__env->startSection('container'); ?>
    <center>
        <h1 class="judul"><?php echo e($title); ?></h1>
        <h4 class="mb-3">Persyaratan sebagai berikut</h4>

        <div class="mar-bot">
            <table border="0">
                <tr>
                    <td>1.</td>
                    <td>Scan KTP Pemohon</td>
                </tr>
                <tr>
                    <td>2.</td>
                    <td>Scan Kartu Keluargan</td>
                </tr>
                <tr>
                    <td>3.</td>
                    <td>Scan SKP (Surat Keterangan Pindah) dari DUKCAPIL</td>
                </tr>
                <tr>
                    <td>4.</td>
                    <td><span>Formulir Warga Penjamin <span class="notice">*Bermaterai 10 Ribu</span></span></td>
                </tr>
                <tr>
                    <td>5.</td>
                    <td>Scan KTP Penjamin</td>
                </tr>
                <tr>
                    <td>6.</td>
                    <td>Scan Kartu Keluarga Penjamin</td>
                </tr>
            </table>
        </div>

        <a href="<?php echo e(asset($jenis->formulir[0])); ?>" target="_blank">
            <button class="download-form-button mb-2">Download Formulir</button>
        </a>
        <a href="<?php echo e(asset($jenis->formulir[1])); ?>" target="_blank">
            <button class="download-form-button mb-2">Download Draft KK</button>
        </a>
        <br>
        <p class="notice-formulir">
            Jika belum memiliki formulir, silahkan download formulir terlebih <br>
            dahulu dengan menekan ‘Download Formulir’ di atas!
        </p>
        <a href="<?php echo e(route('form-perm', ['form' => 'pd'])); ?>">
            <button class="perm-button">Selanjutnya</button>
        </a>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/persy-perm-pd.blade.php ENDPATH**/ ?>