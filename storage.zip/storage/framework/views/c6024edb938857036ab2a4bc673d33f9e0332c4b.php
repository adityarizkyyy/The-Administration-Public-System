<nav class="navbar navbar-expand-lg navbar-light bg-none">
    <div class="container mt-2">
        <a class="navbar-brand" href="/"><span class="blue"><b>APEM15</b></span></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                
                <a class="nav-link <?php echo e(($title === 'Home') ? 'active' : ''); ?>" aria-current="page" href="/"><span
                            class="color-link-nav">Home</span></a>

                <a class="nav-link 
                <?php echo e(($title === 'Permohonan') ? 'active' : ''); ?> 
                <?php echo e(($title === 'Permohonan Penerbitan KTP') ? 'active' : ''); ?>

                <?php echo e(($title === 'Permohonan Penerbitan KK') ? 'active' : ''); ?>

                <?php echo e(($title === 'Permohonan Pengajuan SKTM') ? 'active' : ''); ?>

                <?php echo e(($title === 'Permohonan Pengajuan KJP') ? 'active' : ''); ?>

                <?php echo e(($title === 'Permohonan Pindah Keluar') ? 'active' : ''); ?>

                <?php echo e(($title === 'Permohonan Pindah Datang') ? 'active' : ''); ?>

                <?php echo e(($title === 'Permohonan Pengajuan Usaha Mikro') ? 'active' : ''); ?>" href="permohonan"><span
                            class="color-link-nav">Permohonan</span></a>
                
                <a class="nav-link <?php echo e(($title === 'Tata Cara') ? 'active' : ''); ?>" href="/tatacara"><span
                            class="color-link-nav">Tata Cara</span></a>
                <?php if(auth()->guard()->check()): ?>
                <a class="nav-link <?php echo e(($title === 'Riwayat') ? 'active' : ''); ?>" href="<?php echo e(route('riwayat')); ?>"><span
                                class="color-link-nav">Riwayat</span></a>
                <a class="nav-link <?php echo e(($title === 'Profil') ? 'active' : ''); ?>" href="/profil"><span
                                class="color-link-nav">Profil</span></a>
                <?php endif; ?>


            </ul>

            <?php if(auth()->guard()->check()): ?>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>"><span class="color-link-nav"><i
                                    class="bi bi-box-arrow-right"></i> Logout</span></a>
                    </li>
                </ul>
            <?php else: ?>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><span class="color-link-nav"><i
                                    class="bi bi-box-arrow-in-right"></i> Login</span></a>
                    </li>
                </ul>

            <?php endif; ?>

        </div>
</nav>
<?php /**PATH D:\aplikasi\APEM15\resources\views/partials/navbar.blade.php ENDPATH**/ ?>