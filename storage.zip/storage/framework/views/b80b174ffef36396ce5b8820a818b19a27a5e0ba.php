

<?php $__env->startSection('container'); ?>

<!-- <h1>tatacara</h1> -->

<div>
    
    <div align="center">
        <img src="img/<?php echo e($img); ?>" alt="tatacara1" width="468">

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplikasi\APEM15\resources\views/tatacara.blade.php ENDPATH**/ ?>