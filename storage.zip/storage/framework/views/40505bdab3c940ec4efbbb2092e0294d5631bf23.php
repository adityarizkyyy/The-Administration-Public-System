<table class="table table-hover">
    <thead>
        <tr>
            <th scope="col">No</th>
            <th scope="col">Tanggal Permohonan</th>
            <th scope="col">No SP</th>
            <th scope="col">Nama Lengkap</th>
            <th scope="col">Wilayah RT</th>
            <th scope="col">No KTP</th>
            <th scope="col">Tempat Lahir</th>
            <th scope="col">Tanggal Lahir</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
            <tr>
                <th scope="row"><?php echo e($key + 1); ?></th>
                <td><?php echo e($item->created_at->format('d-m-Y')); ?></td>
                <td><?php echo e($item->suratPermohonan?->nosp); ?></td>
                <td><?php echo e($item->user?->personal?->nama); ?></td>
                <td><?php echo e($item->user?->personal?->wilayahrt); ?></td>
                <td><?php echo e($item->user?->personal?->noktp); ?></td>
                <td><?php echo e($item->user?->personal?->tempatlahir); ?></td>
                <td><?php echo e($item->user?->personal?->tgllahir->format('d-m-Y')); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8">
                    <p align="center">Data Kosong</p>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/exports/laporan.blade.php ENDPATH**/ ?>