

<?php $__env->startSection('container-rt'); ?>
    <center>
        <?php if($edit): ?>
            <form action="<?php echo e(route('rt.profil.update', auth()->user())); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
        <?php endif; ?>
        <h1 class="judul"><?php echo e($title); ?></h1>

        <div class="tabel-profil">
            <table border="0">
            <tr>
                    <td>Nama Lengkap</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="text" class="form-control" id="inputNama" placeholder="Nama Lengkap"
                                value="<?php echo e(auth()->user()->personal?->nama); ?>" name="nama">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->nama); ?>

                        <?php endif; ?>
                    </td>
                </tr>

                <tr>
                    <td>Email</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="email" class="form-control" id="inputEmail" placeholder="Email"
                                value="<?php echo e(auth()->user()->email); ?>" name="email">
                        <?php else: ?>
                            <?php echo e(auth()->user()->email); ?>

                        <?php endif; ?>
                    </td>
                </tr>

                <tr>
                    <td>Nomor Handphone</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="text" class="form-control" id="inputHp" placeholder="Nomor Handphone"
                                value="<?php echo e(auth()->user()->personal?->nohp); ?>" name="nohp">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->nohp); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <select class="form-select" aria-label="Default select example" name="jk">
                                <option <?php if(auth()->user()->personal?->jk === 'Laki-laki'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Laki-laki">
                                    Laki-laki</option>
                                <option <?php if(auth()->user()->personal?->jk === 'Perempuan'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Perempuan">
                                    Perempuan</option>
                            </select>
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->jk); ?>

                        <?php endif; ?>
                    </td>
                </tr>

                <tr>
                    <td>Agama</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                        <select class="form-select" aria-label="Default select example" name="agama">
                            <option <?php if(auth()->user()->personal?->agama === 'Islam'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Islam">Islam</option>
                            <option <?php if(auth()->user()->personal?->agama === 'Protestan'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Protestan">Protestan</option>
                            <option <?php if(auth()->user()->personal?->agama === 'Katolik'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Katolik">Katolik</option>
                            <option <?php if(auth()->user()->personal?->agama === 'Hindu'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Hindu">Hindu</option>
                            <option <?php if(auth()->user()->personal?->agama === 'Buddha'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Buddha">Buddha</option>
                            <option <?php if(auth()->user()->personal?->agama === 'Khonghucu'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Khonghucu">Khonghucu</option>
                        </select>
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->agama); ?>

                        <?php endif; ?>
                    </td>
                </tr>

                <tr>
                    <td>Nomor KTP</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="text" class="form-control" id="inputKtp" placeholder="Nomor KTP"
                                value="<?php echo e(auth()->user()->personal?->noktp); ?>" name="noktp">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->noktp); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Tempat Lahir</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="text" class="form-control" id="inputtempatlahir" placeholder="Tempat Lahir"
                                value="<?php echo e(auth()->user()->personal?->tempatlahir); ?>" name="tempatlahir">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->tempatlahir); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="date" class="form-control" id="inputtanggallahir" placeholder="Tanggal Lahir"
                                value="<?php echo e(auth()->user()->personal?->tgllahir->format('Y-m-d')); ?>" name="tgllahir">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->tgllahir->format('d-m-Y')); ?>

                        <?php endif; ?>
                    </td>
                    </td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <select class="form-select" aria-label="Default select example" name="status">
                                <option <?php if(auth()->user()->personal?->status === 'Belum Menikah'): ?> <?php echo e('selected '); ?> <?php endif; ?>
                                    value="Belum Menikah">
                                    Belum Menikah</option>
                                <option <?php if(auth()->user()->personal?->status === 'Sudah Menikah'): ?> <?php echo e('selected '); ?> <?php endif; ?>
                                    value="Sudah Menikah">Sudah Menikah</option>
                                <option <?php if(auth()->user()->personal?->status === 'Cerai Mati'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Cerai Mati">Cerai Mati</option>
                                <option <?php if(auth()->user()->personal?->status === 'Cerai Hidup'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Cerai Hidup">Cerai Hidup</option>
                            </select>
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->status); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="text" class="form-control" id="inputpekerjaan" placeholder="Pekerjaan"
                                value="<?php echo e(auth()->user()->personal?->pekerjaan); ?>" name="pekerjaan">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->pekerjaan); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Wilayah RT</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <!-- <input type="text" class="form-control" id="inputwilayahrt" placeholder="Wilayah RT"
                                value="<?php echo e(auth()->user()->personal?->wilayahrt); ?>" name="wilayahrt"> -->
                            
                            <select class="form-select" aria-label="Default select example" name="wilayahrt">
                                <option <?php if(auth()->user()->personal?->wilayahrt === '01'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="01">01</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '02'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="02">02</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '03'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="03">03</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '04'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="04">04</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '05'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="05">05</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '06'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="06">06</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '07'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="07">07</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '08'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="08">08</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '09'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="09">09</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '10'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="10">10</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '11'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="11">11</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '12'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="12">12</option>
                                <option <?php if(auth()->user()->personal?->wilayahrt === '13'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="13">13</option>
                            </select>
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->wilayahrt); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            </table>
            <?php if($edit): ?>
                <?php if($edit): ?>
                    <button type="submit" class="pro-button mt-3">Simpan Perubahan</button>
                    </form>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(route('rt.profil', ['edit' => true])); ?>">
                    <button class="pro-button mt-5">Ubah Profil</button>
                </a>
            <?php endif; ?>
        </div>

        <!-- <a href="<?php echo e(route('rt.index')); ?>">
            <button class="pro-button">Kembali Ke HOME</button>
        </a> -->
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-rt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplikasi\APEM15\resources\views/profil-rt.blade.php ENDPATH**/ ?>