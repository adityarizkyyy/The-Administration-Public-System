<h3><?php echo e($details['greeting']); ?></h3>

<p><?php echo e($details['message']); ?></p>
<?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/emails/notification.blade.php ENDPATH**/ ?>