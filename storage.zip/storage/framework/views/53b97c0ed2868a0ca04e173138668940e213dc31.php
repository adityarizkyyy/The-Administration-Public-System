

<?php $__env->startSection('container'); ?>
    <div class="container_home">
        <div class="content1_home">
            <h1 class="blue"><b><?php echo e($kata1); ?></b></h1>
            <h1 class="blue"><b><?php echo e($kata2); ?></b></h1>
            <h5 class="blue"><?php echo e($kata3); ?></h5>
            <h5 class="blue"><?php echo e($kata4); ?></h5>
            <p class="pad-top-home"></p>
            <a href="<?php echo e(route('permohonan')); ?>"><button class="main-button">Ajukan Permohonan</button></a>
            <!-- <a href="<?php echo e(route('tatacara')); ?>"><button class="tanya-button">?</button></a> -->
        </div>

        <div class="content2_home">
            <img class="mainchar" src="img/<?php echo e($img); ?>" alt="mainchar">
        </div>
    </div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplikasi\APEM15\resources\views/home.blade.php ENDPATH**/ ?>