

<?php $__env->startSection('container'); ?>
    <center>
        <h1 class="judul"><?php echo e($title); ?></h1>
        <h4 class="mb-4">Persyaratan sebagai berikut</h4>

        <div class="mar-bot">
            <table border="0">
                <tr>
                    <td>1.</td>
                    <td>Scan Kartu Keluarga</td>
                </tr>
                <tr>
                    <td>2.</td>
                    <td>Scan Akta Kelahiran</td>
                </tr>
                <tr>
                    <td>3.</td>
                    <td>Scan KTP Kepala Keluarga</td>
                </tr>
            </table>
        </div>

        <a href="<?php echo e(route('form-perm', ['form' => 'ktp'])); ?>">
            <button class="perm-button">Selanjutnya</button>
        </a>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplikasi\APEM15\resources\views/persy-perm-ktp.blade.php ENDPATH**/ ?>