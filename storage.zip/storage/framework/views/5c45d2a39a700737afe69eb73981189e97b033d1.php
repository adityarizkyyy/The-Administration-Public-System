

<?php $__env->startSection('container-rw'); ?>
    <center>
        <h1 class="judul"><?php echo e($title); ?></h1>
    </center>

    <div class="container">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Jenis Permohonan</th>
                        <th scope="col">Nama Lengkap</th>
                        <th scope="col">Wilayah RT</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($key + 1); ?></th>
                            <td><?php echo e($item->jenisPermohonan?->jenis_permohonan); ?></td>
                            <td><?php echo e($item->user?->personal?->nama); ?></td>
                            <td><?php echo e($item->user?->personal?->wilayahrt); ?></td>
                            <!-- <td><a onclick="event.stopPropagation()"
                                    href="<?php echo e(route('download', ['link' => $item->suratPengantar?->filesk])); ?>"
                                    target="_blank" class="btn btn-secondary btn-sm">Open File</a></td> -->
                            <td>
                                <a onclick="window.location = '<?php echo e(route('rw.persetujuan', ['permohonan' => $item])); ?>'"
                                href=""
                                target="_blank" class="btn button-unduh btn-sm">Aksi</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">
                                <p align="center">Data Kosong</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-rw', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplikasi\APEM15\resources\views/rw-permintaan.blade.php ENDPATH**/ ?>