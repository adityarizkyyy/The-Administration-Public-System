

<?php $__env->startSection('container'); ?>
    <center>
        <h1 class="judul">Silahkan Pilih Permohonan</h1>
        <p class="judul"></p>
        <div class="judul">
            <a href="<?php echo e(route('persyaratan', ['need' => 'ktp'])); ?>">
                <button class="perm-button">Penerbitan Kartu Tanda Penduduk (KTP)</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'kk'])); ?>">
                <button class="perm-button">Penerbitan Kartu Keluarga (KK)</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'sktm'])); ?>">
                <button class="perm-button">Pengajuan Surat Keterangan Tidak Mampu (SKTM)</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'kjp'])); ?>">
                <button class="perm-button">Pengajuan Kartu Jakarta Pintar (KJP)</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'pk'])); ?>">
                <button class="perm-button">Pindah Keluar</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'pd'])); ?>">
                <button class="perm-button">Pindah Datang</button>
            </a>
            <p></p>
            <a href="<?php echo e(route('persyaratan', ['need' => 'um'])); ?>">
                <button class="perm-button">Pengajuan Usaha Mikro</button>
            </a>

        </div>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplikasi\APEM15\resources\views/permohonan.blade.php ENDPATH**/ ?>