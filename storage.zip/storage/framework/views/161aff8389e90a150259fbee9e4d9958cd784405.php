

<?php $__env->startSection('container-rt'); ?>
    <center>
        <h1 class="judul"><?php echo e($judul); ?></h1>
    </center>

    <div class="container">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Jenis Permohonan</th>
                        <th scope="col">Nama Lengkap</th>
                        <th scope="col">Agama</th>
                        <th scope="col">No KTP</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr onclick="window.location = '<?php echo e(route('rt.permintaan', ['permohonan' => $item])); ?>'"
                            style="cursor: pointer;">
                            <!-- kalau mau yang di klik cuman bisa button doang, yg di tr dihapus full aja -->
                            <th scope="row"><?php echo e($key + 1); ?></th>
                            <td><?php echo e($item->jenisPermohonan?->jenis_permohonan); ?></td>
                            <td><?php echo e($item->user?->personal?->nama); ?></td>
                            <td><?php echo e($item->user?->personal?->agama); ?></td>
                            <td><?php echo e($item->user?->personal?->noktp); ?></td>
                            <td><a onclick="window.location = '<?php echo e(route('rt.permintaan', ['permohonan' => $item])); ?>'"
                                    href=""
                                    target="_blank" class="btn button-unduh btn-sm">Aksi</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">
                                <p align="center">Data Kosong</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-rt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplikasi\APEM15\resources\views/rt-home.blade.php ENDPATH**/ ?>