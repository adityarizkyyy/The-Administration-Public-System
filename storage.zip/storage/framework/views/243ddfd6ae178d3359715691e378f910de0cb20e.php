<h3><?php echo e($details['greeting']); ?></h3>

<p><?php echo e($details['message']); ?></p>
<?php /**PATH D:\aplikasi\APEM15\resources\views/emails/notification.blade.php ENDPATH**/ ?>