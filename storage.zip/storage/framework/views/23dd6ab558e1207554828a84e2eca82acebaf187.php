

<?php $__env->startSection('container'); ?>
    <center>
        <?php if($edit): ?>
            <form action="<?php echo e(route('profil.update', auth()->user())); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
        <?php endif; ?>
        <h1 class="judul"><?php echo e($title); ?></h1>

        <div class="tabel-profil">
            <table border="0">
                <tr>
                    <td>Nama Lengkap</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="text" class="form-control" id="inputNama" placeholder="Nama Lengkap"
                                value="<?php echo e(auth()->user()->personal?->nama); ?>" name="nama">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->nama); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Nomor Handphone</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="text" class="form-control" id="inputHp" placeholder="Nomor Handphone"
                                value="<?php echo e(auth()->user()->personal?->nohp); ?>" name="nohp">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->nohp); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <select class="form-select" aria-label="Default select example" name="jk">
                                <option <?php if(auth()->user()->personal?->jk === 'Laki-laki'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Laki-laki">
                                    Laki-laki</option>
                                <option <?php if(auth()->user()->personal?->jk === 'Perempuan'): ?> <?php echo e('selected '); ?> <?php endif; ?> value="Perempuan">
                                    Perempuan</option>
                            </select>
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->jk); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Nomor KTP</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="text" class="form-control" id="inputKtp" placeholder="Nomor KTP"
                                value="<?php echo e(auth()->user()->personal?->noktp); ?>" name="noktp">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->noktp); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Tempat Lahir</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="text" class="form-control" id="inputtempatlahir" placeholder="Tempat Lahir"
                                value="<?php echo e(auth()->user()->personal?->tempatlahir); ?>" name="tempatlahir">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->tempatlahir); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="date" class="form-control" id="inputtanggallahir" placeholder="Tanggal Lahir"
                                value="<?php echo e(auth()->user()->personal?->tgllahir->format('Y-m-d')); ?>" name="tgllahir">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->tgllahir->format('d-m-Y')); ?>

                        <?php endif; ?>
                    </td>
                    </td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <select class="form-select" aria-label="Default select example" name="status">
                                <option <?php if(auth()->user()->personal?->status === 'Belum Menikah'): ?> <?php echo e('selected '); ?> <?php endif; ?>
                                    value="Belum Menikah">
                                    Belum Menikah</option>
                                <option <?php if(auth()->user()->personal?->status === 'Sudah Menikah'): ?> <?php echo e('selected '); ?> <?php endif; ?>
                                    value="Sudah Menikah">Sudah Menikah</option>
                            </select>
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->status); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="text" class="form-control" id="inputpekerjaan" placeholder="Pekerjaan"
                                value="<?php echo e(auth()->user()->personal?->pekerjaan); ?>" name="pekerjaan">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->pekerjaan); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Wilayah RT</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <?php if($edit): ?>
                            <input type="text" class="form-control" id="inputwilayahrt" placeholder="Wilayah RT"
                                value="<?php echo e(auth()->user()->personal?->wilayahrt); ?>" name="wilayahrt">
                        <?php else: ?>
                            <?php echo e(auth()->user()->personal?->wilayahrt); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            </table>
            <?php if($edit): ?>
                <?php if($edit): ?>
                    <button type="submit" class="pro-button mt-3">Simpan Perubahan</button>
                    </form>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(route('profil', ['edit' => true])); ?>">
                    <button class="pro-button mt-3">Ubah Profil</button>
                </a>
            <?php endif; ?>
        </div>

        <a href="<?php echo e(route('home')); ?>">
            <button class="pro-button">Kembali Ke HOME</button>
        </a>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/profil.blade.php ENDPATH**/ ?>