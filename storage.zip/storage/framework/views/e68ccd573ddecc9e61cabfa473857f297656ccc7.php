

<?php $__env->startSection('container'); ?>
    <div class="main-box-form">
        <h1 class="mb-5" align="center"><?php echo e($title); ?></h1>
        <div>
            <div>
                <div class="sec-box-form">
                    <!-- col-lg-4 : colom-large(panjang)-8-->
                    <form action="<?php echo e(route('form-perm', ['form' => 'ktp'])); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div class="mb-3">
                            <label for="formFile" class="form-label">Kartu Keluarga</label>
                            <input class="form-control" type="file" id="formFile" name="filekk" required>
                        </div>
                        <div class="mb-3">
                            <label for="formFile" class="form-label">Akta Kelahiran</label>
                            <input class="form-control" type="file" id="formFile" name="fileakta" required>
                        </div>
                        <div class="mb-5">
                            <label for="formFile" class="form-label">KTP Kepala Keluarga</label>
                            <input class="form-control" type="file" id="formFile" name="filektpkepalart" required>
                        </div>
                        <span>
                            <center>
                                <button type="submit" class="sec-button">Ajukan Permohonan</button>
                            </center>
                        </span>

                    </form>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplikasi\APEM15\resources\views/perm-ktp.blade.php ENDPATH**/ ?>