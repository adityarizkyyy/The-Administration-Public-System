

<?php $__env->startSection('container'); ?>
    <center>
        <h1 class="judul"><?php echo e($title); ?></h1>
        <h4 class="mb-4">Persyaratan sebagai berikut</h4>

        <div class="mar-bot">
            <table border="0">
                <tr>
                    <td>1.</td>
                    <td>Scan KTP Pemohon</td>
                </tr>
                <tr>
                    <td>2.</td>
                    <td>Scan Kartu Keluargan</td>
                </tr>
            </table>
        </div>

        <center>
            <a href="<?php echo e(route('form-perm', ['form' => 'pk'])); ?>">
                <button class="perm-button">Selanjutnya</button>
            </a>
        </center>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/persy-perm-pk.blade.php ENDPATH**/ ?>