

<?php $__env->startSection('container-rt'); ?>
    <center>
        <h1 class="judul"><?php echo e($title); ?></h1>
    </center>

    
    <center>
        <div class="tabel-profil">
            
            <table border="0">
                <tr>
                    <td>Jenis Permohonan</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->jenisPermohonan->jenis_permohonan); ?></td>
                </tr>
                <tr>
                    <td>Nama Lengkap</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->nama); ?></td>
                </tr>
                <tr>
                    <td>Tempat Lahir</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->tempatlahir); ?></td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->tgllahir->format('d-m-Y')); ?></td>
                    </td>
                </tr>
                <tr>
                    <td>Nomor KTP</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->noktp); ?></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->jk); ?></td>
                </tr>
                <tr>
                    <td>Agama</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->agama); ?></td>
                </tr>
                
                
                <tr>
                    <td>Status</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->status); ?></td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->pekerjaan); ?></td>
                </tr>
                <tr>
                    <td>Wilayah RT</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->wilayahrt); ?></td>
                </tr>
                <?php if(isset($permohonan->form->displayInformation()['var'])): ?>
                    <?php $__currentLoopData = $permohonan->form->displayInformation()['var']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item[0]); ?></td>
                            <td class="titikdua">:</td>
                            <td class="identitas"><?php echo e($item[1]); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(isset($permohonan->form->displayInformation()['file'])): ?>
                    <?php $__currentLoopData = $permohonan->form->displayInformation()['file']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(is_array($item[1])): ?>
                            <?php $__currentLoopData = $item[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datakey => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>Berkas <?php echo e($item[0] . ' ' . $datakey + 1); ?></td>
                                    <td class="titikdua">:</td>
                                    <td class="identitas">
                                        <a href="<?php echo e(route('download', ['link' => $data])); ?>" target="_blank"
                                            class="btn button-unduh btn-sm">Open File</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td><?php echo e($item[0]); ?></td>
                                <td class="titikdua">:</td>
                                <td class="identitas">
                                    <a href="<?php echo e(route('download', ['link' => $item[1]])); ?>" target="_blank"
                                        class="btn button-unduh btn-sm">Open File</a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </table>
        </div>
    </center>


    <center>
        <a href="<?php echo e(route('rt.sp', ['permohonan' => $permohonan])); ?>">
            <!--ketika klik setujui permintaan, beralih ke halaman rt-upload-sk -->
            <button class="button-login mt-3">
                Setujui Permintaan
            </button>
        </a><br>
        <form action="<?php echo e(route('rt.sp', ['permohonan' => $permohonan, 'status' => 'tolak'])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <!-- ketika klik tolak, status progres diupdate jadi : Permintaan Permohonan DITOKLAK, sembari kirim email ke email yg terdaftar : Permintaan Ditolak, selahkan periksa data diri dan persyatan dengan benar -->
            <button class="button-tolak mt-1 mb-5" type="submit">
                Tolak
            </button>
        </form>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-rt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplikasi\APEM15\resources\views/rt-permintaan.blade.php ENDPATH**/ ?>