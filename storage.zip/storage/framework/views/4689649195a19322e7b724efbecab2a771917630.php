

<?php $__env->startSection('container-rw'); ?>

    <center>
        <h1 class="judul"><?php echo e($title); ?></h1>
    </center>

    <center>
        <div class="tabel-profil">
            
            <table border="0">
                <tr>
                    <td>Jenis Permohonan</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->jenisPermohonan->jenis_permohonan); ?></td>
                </tr>
                <tr>
                    <td>Nama Lengkap</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->nama); ?></td>
                </tr>
                <tr>
                    <td>File SK RT</td>
                    <td class="titikdua">:</td>
                    <td class="identitas">
                        <a href="<?php echo e(route('download', ['link' => $permohonan->suratPengantar->filesk])); ?>" target="_blank"
                            class="btn btn-secondary btn-sm">Open File</a>
                    </td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->jk); ?></td>
                </tr>
                <tr>
                    <td>Nomor KTP</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->noktp); ?></td>
                </tr>
                <tr>
                    <td>Tempat Lahir</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->tempatlahir); ?></td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->tgllahir->format('d-m-Y')); ?></td>
                    </td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->status); ?></td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->pekerjaan); ?></td>
                </tr>
                <tr>
                    <td>Wilayah RT</td>
                    <td class="titikdua">:</td>
                    <td class="identitas"><?php echo e($permohonan->user?->personal?->wilayahrt); ?></td>
                </tr>
                <?php if(isset($permohonan->form->displayInformation()['var'])): ?>
                    <?php $__currentLoopData = $permohonan->form->displayInformation()['var']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item[0]); ?></td>
                            <td class="titikdua">:</td>
                            <td class="identitas"><?php echo e($item[1]); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(isset($permohonan->form->displayInformation()['file'])): ?>
                    <?php $__currentLoopData = $permohonan->form->displayInformation()['file']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(is_array($item[1])): ?>
                            <?php $__currentLoopData = $item[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datakey => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>Berkas <?php echo e($item[0] . ' ' . $datakey + 1); ?></td>
                                    <td class="titikdua">:</td>
                                    <td class="identitas">
                                        <a href="<?php echo e(route('download', ['link' => $data])); ?>" target="_blank"
                                            class="btn btn-secondary btn-sm">Open File</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td><?php echo e($item[0]); ?></td>
                                <td class="titikdua">:</td>
                                <td class="identitas">
                                    <a href="<?php echo e(route('download', ['link' => $item[1]])); ?>" target="_blank"
                                        class="btn btn-secondary btn-sm">Open File</a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </table>
        </div>
    </center>


    <center>
        <a href="<?php echo e(route('rw.sp', [$permohonan])); ?>">
            <button class="button-login mt-5">
                Setujui Permohonan
            </button>
        </a>
        </a>
    </center>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-rw', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/rw-permintaan-persetujuan.blade.php ENDPATH**/ ?>