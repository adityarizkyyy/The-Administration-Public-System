

<?php $__env->startSection('container-rt'); ?>
    <div class="main-box-form">
        <center>
            <h1 class="judul"><?php echo e($title); ?></h1>
            <h4 class="notice"><?php echo e($notice); ?></h4>
        </center>
        <div>
            <div>
                <div class="sec-box-form">
                    <!-- col-lg-4 : colom-large(panjang)-8-->
                    <form action="<?php echo e(route('rt.sp', ['permohonan' => $permohonan])); ?>" enctype="multipart/form-data"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-5 mt-5">
                            <label for="formFile" class="form-label">Scan Surat Pengantar</label>
                            <input class="form-control" type="file" id="formFile" name="filesk">
                        </div>

                        <span>
                            <center>
                                <!-- ketika rt klik upload sk, status progres juga diupdate jadi : Validasi pertama berhasil-->
                                <button type="submit" class="sec-button mt-5 ">Upload</button>
                            </center>
                        </span>

                    </form>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-rt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Haiqal Rama A\Desktop\Aditya\APEM15\resources\views/rt-upload-sk.blade.php ENDPATH**/ ?>